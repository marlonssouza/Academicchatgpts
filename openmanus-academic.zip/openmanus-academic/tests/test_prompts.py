from app.prompts import build_prompt


def test_tcc_prompt_is_academic_only():
    text = build_prompt("tcc", "Analise o capítulo", "conteúdo")
    assert "TCC" not in text or "tcc" in text.lower()
    assert "gestão de escritório" in text
    assert "Não misture" in text


def test_invalid_mode():
    try:
        build_prompt("office", "x")
    except ValueError:
        return
    raise AssertionError("modo inválido deveria falhar")
