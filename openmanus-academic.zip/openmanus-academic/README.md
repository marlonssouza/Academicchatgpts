# OpenManus Academic

Aplicação independente para dar capacidades de execução acadêmica aos GPTs Orientador Acadêmico UNDB e Coach TCC, sem qualquer vínculo funcional com o SaaS jurídico.

## Funções

- `tcc`: coerência entre projeto, problema, objetivos, método, capítulos e conclusão
- `case`: análise de CASE jurídico
- `paper`: análise de PAPER jurídico
- `abnt`: auditoria de citações e referências
- `references`: verificação de referências e dados ausentes
- `compare`: comparação de versões/documentos
- `research`: pesquisa acadêmica verificável

## Endpoints

- `GET /health`
- `GET /modes`
- `POST /v1/academic/run`
- `GET /openapi.json`
- `GET /privacy`

## Segurança

Use `X-API-Key` no GPT Action. A chave deve ser configurada como `ACADEMIC_API_KEY` no servidor.

## Uso local

```bash
cp .env.example .env
pip install -r requirements.txt
bash build.sh
ACADEMIC_API_KEY=teste OPENMANUS_API_KEY=sua-chave bash start.sh
```

## GPT Actions

Depois do deploy HTTPS:

1. Abra o editor do GPT existente.
2. Vá até **Ações** e crie uma nova ação.
3. Configure autenticação por **API key**, cabeçalho `X-API-Key`.
4. Importe `https://SEU-DOMINIO/openapi.json` ou cole o schema.
5. Teste `runAcademicTask` na prévia.

O GPT Orientador UNDB deve chamar modos `case`, `paper`, `abnt`, `references` e `research`.
O Coach TCC deve priorizar `tcc`, `compare`, `abnt`, `references` e `research`.
